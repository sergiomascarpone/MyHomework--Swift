import UIKit

let temperature = 12
let windSpeed = 5

let weatherDiscription = "Temperature ic about 12`C above zero wind speed is about 5 m/s"
let weatherDiscriptionI = "Temperature is about \(temperature)`C above zero and wind speed is about \(windSpeed) m/s"

let string = "\(1 + 2)" + "\(2 + 3)"
